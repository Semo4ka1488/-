
-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE `product` (
  `id` int NOT NULL,
  `pname` varchar(255) NOT NULL,
  `pimage` varchar(255) NOT NULL,
  `pcategory` varchar(255) NOT NULL,
  `pprice` decimal(10,2) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id`, `pname`, `pimage`, `pcategory`, `pprice`, `status`) VALUES
(22, 'Lego City ', 'uploads/8.jpg', 'constructor', '120.00', 'active'),
(23, 'Lego Duplo', 'uploads/2.jpg', 'constructor', '89.00', 'active'),
(24, 'Teddy Pink', 'uploads/5.jpg', 'forbaby', '15.00', 'active'),
(25, 'Pony Island', 'uploads/10.jpg', 'forgirls', '36.00', 'active'),
(26, 'Lego Tehnik', 'uploads/1.jpg', 'constructor', '350.00', 'active'),
(27, 'Lego Creator', 'uploads/3.jpg', 'constructor', '45.00', 'active'),
(28, 'Lego Duplo', 'uploads/4.jpg', 'constructor', '130.00', 'active'),
(29, 'Poni Island', 'uploads/9.jpg', 'forgirls', '67.00', 'active'),
(30, 'Papa Teddy', 'uploads/6.jpg', 'forbaby', '299.00', 'active'),
(31, 'Baby Shark', 'uploads/11.jpg', 'forbaby', '99.00', 'active'),
(32, 'Fashion Baby ', 'uploads/12.jpg', 'forgirls', '29.00', 'active'),
(33, 'Grey Teddy', 'uploads/13.jpg', 'forbaby', '46.00', 'active'),
(34, 'Vinni Pooh', 'uploads/изображение_2023-12-10_221241138.png', 'forbaby', '69.00', 'active'),
(35, 'Lego Duplo', 'uploads/15.jpg', 'constructor', '170.00', 'active'),
(36, 'Lego Creator', 'uploads/16.jpg', 'constructor', '99.00', 'active'),
(38, 'Lego Tehnik', 'uploads/17.jpg', 'constructor', '599.00', 'active');
