
-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`) VALUES
(1, 'romdom', '$2y$10$frzmb9KLNpSg8212hC2qY.tK6/GjHrlAJFUiVhoiKDVfdGg9KRkGy', 'poop.romdom@yandex.ru'),
(3, 'qwe', '$2y$10$IrN8RTGKkB9WLm2jtO3DSuzCBLEJeOZDuVmh900ayhZWtWvq71ydS', '45y46y4@melgntrg'),
(5, 'David', '$2y$10$/xsm9RZJffBa/jqy/ED67OKbQD8vEuompl4DoAisewnwdTcblB1R2', 'dfc@mail.ru');
